package com.fis.sprint3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Sprint3Application {

	public static void main(String[] args) {
		SpringApplication.run(Sprint3Application.class, args);
	}

}
