package com.fresher.core;

public enum CaseType {
    UNCATEGORIZED,
    INFRACTION,
    MISDEMEANOR,
    FELONY
}