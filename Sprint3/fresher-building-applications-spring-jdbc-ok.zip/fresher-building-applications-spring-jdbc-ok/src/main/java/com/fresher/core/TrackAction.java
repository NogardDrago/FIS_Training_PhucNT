package com.fresher.core;

public enum TrackAction {
    SUBMITTED,
    RETRIEVED,
    RETURNED
}
