package com.fresher.core;

public class NotImplementedException extends RuntimeException{
    public NotImplementedException(String message) {
        super(message);
    }
}
