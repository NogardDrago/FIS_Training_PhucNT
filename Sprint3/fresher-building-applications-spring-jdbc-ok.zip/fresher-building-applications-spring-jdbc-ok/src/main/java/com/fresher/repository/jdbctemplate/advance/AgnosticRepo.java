package com.fresher.repository.jdbctemplate.advance;

public interface AgnosticRepo {
    int createTable(String name);
}
