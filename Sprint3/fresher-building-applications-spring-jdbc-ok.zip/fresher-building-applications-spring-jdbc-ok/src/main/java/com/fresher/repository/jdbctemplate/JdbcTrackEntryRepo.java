package com.fresher.repository.jdbctemplate;

public class JdbcTrackEntryRepo {
    //TODO
}
