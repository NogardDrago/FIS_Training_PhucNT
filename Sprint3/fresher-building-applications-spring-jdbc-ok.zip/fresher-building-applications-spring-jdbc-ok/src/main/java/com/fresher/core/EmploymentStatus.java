package com.fresher.core;

public enum EmploymentStatus {
    ACTIVE,
    SUSPENDED,
    VACATION,
    UNDER_INVESTIGATION,
    RETIRED
}
