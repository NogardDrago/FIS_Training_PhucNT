package com.fresher.repository.jdbctemplate;

public class JdbcEvidenceRepo {
    //TODO ...
}
